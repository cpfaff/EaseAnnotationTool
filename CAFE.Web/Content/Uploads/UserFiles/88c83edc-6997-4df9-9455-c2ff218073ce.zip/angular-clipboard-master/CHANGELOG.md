## [1.5.0] - 2016-08-23
- Prevent scroll to the top on copy in IE.
- Use injected document for supported check.

## [1.4.2] - 2016-05-16
- Prevent scroll to bottom in IE by inserting node at same top position.

## [1.4.1] - 2016-04-21
- Make 'supported' property optional.

## [1.4.0] - 2016-04-15
- Support for feature detection exposed through both factory and dynamic property.

## [1.3.0] - 2016-01-12
- Add UMD support.

## [1.2.1] - 2016-01-04
- Reset inline styles on error.

## [1.2.0] - 2015-12-11
- Add clipboard service exposing copyText().

## [1.1.2] - 2015-11-20
- Fix angular scope call.

## [1.1.1] - 2015-10-02
- Correctly fail on Safari.

## [1.0.1] - 2015-09-15
- Add support for multiline.

## [1.0.1] - 2015-07-14
- Remove dependency on $window.

## [1.0.0] - 2015-07-14
- First release.
